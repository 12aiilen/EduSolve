<?php
require_once __DIR__ . '/../DAL/MateriaDAL.php';

class MateriaBLL {

    private $dal;

    public function __construct() {
        $this->dal = new MateriaDAL();
    }

public function obtenerPorIds(array $ids): array {
    $materiaDAL = new MateriaDAL();
    return $materiaDAL->getByIds($ids);
}

    public function eliminarMateria($id) {
        return $this->dal->eliminar($id);
    }

    public function actualizarMateria($id, $nombre, $descripcion, $horas_semanales = null, $anio = null) {
        if (empty($id) || empty($nombre)) {
            throw new Exception("El ID y el nombre son obligatorios");
        }
        return $this->dal->actualizar($id, $nombre, $descripcion, $horas_semanales, $anio);
    }

    // 🔹 NUEVO: insertar materia y devolver ID
    public function insertar($nombre, $descripcion, $horas_semanales, $anio) {
        if (empty($nombre)) {
            throw new Exception("El nombre de la materia es obligatorio");
        }
        return $this->dal->insertar($nombre, $descripcion, $horas_semanales, $anio);
    }
}
?>
